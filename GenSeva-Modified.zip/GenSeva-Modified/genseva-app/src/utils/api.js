import { LANGUAGES } from '../data/schemes'

const LANG_NAMES = {
  en: 'English', hi: 'Hindi (हिंदी)', te: 'Telugu (తెలుగు)',
  ta: 'Tamil (தமிழ்)', bn: 'Bengali (বাংলা)', mr: 'Marathi (मराठी)',
  kn: 'Kannada (ಕನ್ನಡ)', gu: 'Gujarati (ગુજરાતી)'
}

export async function callClaude(messages, lang, customSystem = null) {
  const langObj = LANGUAGES.find(l => l.code === lang) || LANGUAGES[0]
  const langName = LANG_NAMES[lang] || 'English'

  const systemPrompt = customSystem || `You are GenSeva AI, an expert AI civic assistant for Indian government welfare schemes.
You help every Indian citizen — farmer, laborer, woman, student, senior citizen — understand and access government schemes without any middlemen.

CRITICAL LANGUAGE INSTRUCTION: You MUST respond ENTIRELY in ${langName}. Every word of your response must be in ${langName}. Do NOT mix languages. Do NOT respond in English unless the selected language is English.

You know all 500+ central and state government schemes including:
PM-KISAN, Ayushman Bharat (PMJAY), PM Awas Yojana, MGNREGS, PM Mudra Yojana, Sukanya Samriddhi Yojana, Atal Pension Yojana, PM Ujjwala 2.0, Kisan Credit Card, PM Scholarship, Stand Up India, PMSBY, PMJJBY, PM Fasal Bima Yojana, NFSA, Swachh Bharat Mission, and state schemes for all 28 states and 8 UTs.

For every query, structure your response clearly:
1. **Overview** — what the scheme is
2. **Eligibility** — who qualifies
3. **Benefits** — exact amounts or services
4. **Required Documents** — complete list
5. **How to Apply** — step-by-step process
6. **Official Portal & Helpline** — where to go

Be warm, simple, and encouraging. Many users have low literacy. Use easy language. Respond in ${langName}.
${langObj.prompt}`

  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ system: systemPrompt, messages, max_tokens: 1000 }),
  })

  const data = await response.json()
  if (!response.ok) throw new Error(data.error || 'Server error')
  return data.content?.[0]?.text || 'Unable to get response. Please try again.'
}

export function formatMarkdown(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong style="color:#14A085;font-weight:600">$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/^#{1,3}\s(.+)$/gm, '<div style="color:#14A085;font-weight:700;margin-top:10px">$1</div>')
    .replace(/\n\n+/g, '</p><p style="margin-top:8px">')
    .replace(/\n/g, '<br/>')
    .replace(/^/, '<p>').replace(/$/, '</p>')
}

export function getTime() {
  return new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
}
