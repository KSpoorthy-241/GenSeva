import { useState, useRef, useCallback } from 'react'
import { callBedrockViaLambda, startTranscribe, speakWithPolly, logToDynamoDB, getCognitoSession } from '../services/awsService'

// ── useChat hook ──────────────────────────────────────
export function useChat(lang) {
  const [messages, setMessages]   = useState([])
  const [loading, setLoading]     = useState(false)
  const [history, setHistory]     = useState([])
  const sessionRef = useRef(getCognitoSession())

  const sendMessage = useCallback(async (text) => {
    if (!text?.trim() || loading) return

    const userMsg = { id: Date.now(), role: 'user', text: text.trim(), time: getTime() }
    setMessages(prev => [...prev, userMsg])
    setLoading(true)

    const newHistory = [...history, { role: 'user', content: text.trim() }]
    setHistory(newHistory)

    try {
      const reply = await callBedrockViaLambda(newHistory, lang)
      const botMsg = { id: Date.now() + 1, role: 'bot', text: reply, time: getTime() }
      setMessages(prev => [...prev, botMsg])
      setHistory(h => [...h, { role: 'assistant', content: reply }].slice(-20))
      logToDynamoDB(sessionRef.current.userId, text, reply)

      // Amazon Polly TTS — auto-speak in English
      if (lang === 'en') speakWithPolly(reply, lang)

    } catch (err) {
      setMessages(prev => [...prev, {
        id: Date.now() + 1, role: 'bot',
        text: '⚠️ Unable to connect to Amazon Bedrock. Please check your connection and try again.',
        time: getTime(), isError: true,
      }])
    }

    setLoading(false)
  }, [loading, history, lang])

  const clearChat = () => { setMessages([]); setHistory([]) }

  return { messages, loading, sendMessage, clearChat }
}

// ── useVoice hook (Amazon Transcribe simulation) ──────
export function useVoice(lang, onTranscript) {
  const [recording, setRecording] = useState(false)
  const recognitionRef = useRef(null)

  const toggle = useCallback(() => {
    if (recording) {
      recognitionRef.current?.stop()
      setRecording(false)
      return
    }

    const r = startTranscribe(
      lang,
      (transcript) => {
        setRecording(false)
        onTranscript(transcript)
      },
      () => setRecording(false),
      (err) => {
        setRecording(false)
        if (err === 'not-supported') {
          // Demo fallback when Speech API unavailable
          const demos = [
            'Tell me about PM-KISAN eligibility for small farmers',
            'What documents do I need for Ayushman Bharat health card?',
            'How to apply for Mudra Loan for my shop?',
          ]
          onTranscript(demos[Math.floor(Math.random() * demos.length)])
        }
      }
    )

    if (r) {
      recognitionRef.current = r
      setRecording(true)
    }
  }, [recording, lang, onTranscript])

  const stop = useCallback(() => {
    recognitionRef.current?.stop()
    setRecording(false)
  }, [])

  return { recording, toggle, stop }
}

// ── utility ───────────────────────────────────────────
export function getTime() {
  return new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
}

export function formatBotText(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong class="text-teal-2">$1</strong>')
    .replace(/\n\n+/g,          '</p><p class="mt-2">')
    .replace(/\n/g,             '<br />')
    .replace(/^/,               '<p>')
    .replace(/$/,               '</p>')
}
