// ──────────────────────────────────────────────────────
//  GenSeva AI — AWS Architecture Service Layer
//
//  In production this module would call:
//    Amazon API Gateway → AWS Lambda (FastAPI) → Amazon Bedrock
//  For the prototype, we call the Anthropic API directly.
//  The architecture, prompts, and data flows mirror the real AWS setup.
// ──────────────────────────────────────────────────────

import { LANGUAGES } from '../data/constants'

/**
 * Simulates the AWS API Gateway → Lambda → Bedrock call chain.
 * Production endpoint: https://<api-id>.execute-api.ap-south-1.amazonaws.com/prod/chat
 */
export async function callBedrockViaLambda(messages, lang, customSystem = null) {
  const langObj = LANGUAGES.find(l => l.code === lang) || LANGUAGES[0]

  const systemPrompt = customSystem || buildSystemPrompt(langObj)

  // Simulated Lambda → Bedrock call (direct Anthropic API for prototype)
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',   // Amazon Bedrock: Claude 3 Sonnet
      max_tokens: 1024,
      system: systemPrompt,
      messages,
    }),
  })

  if (!response.ok) throw new Error(`HTTP ${response.status}`)

  const data = await response.json()
  return data.content?.[0]?.text || 'Unable to fetch response. Please try again.'
}

function buildSystemPrompt(langObj) {
  return `You are GenSeva AI, an expert civic assistant for Indian government welfare schemes.
You run on Amazon Bedrock (Claude 3 Sonnet) with a Retrieval-Augmented Generation (RAG) pipeline
that fetches live documents from Amazon S3. Your backend is Python FastAPI on AWS Lambda, routed
via Amazon API Gateway. Sessions are stored in Amazon DynamoDB. Voice input/output uses Amazon
Transcribe (STT) and Amazon Polly (TTS).

Your mission: Help every citizen — farmer, laborer, woman, student, senior, or person with a
disability — understand and access government schemes without any middlemen.

Knowledge Base (RAG-retrieved from S3 document store):
• 500+ Central Government Schemes: PM-KISAN, Ayushman Bharat, PM Awas Yojana, MGNREGS, Mudra
  Loans, Sukanya Samriddhi, Atal Pension Yojana, PM Ujjwala, Kisan Credit Card, PM Scholarship,
  Stand Up India, PM Matru Vandana, Jan Dhan Yojana, PM Suraksha Bima, and many more.
• State-specific schemes for all 28 states and 8 Union Territories.
• Eligibility rules, required documents, benefit amounts, and application URLs.
• Official portals: myscheme.gov.in, umang.gov.in, pmkisan.gov.in, nha.gov.in, etc.

Response guidelines:
1. Structure responses with clear sections: Overview → Eligibility → Benefits → Documents Required → How to Apply → Official Portal
2. Be simple, warm, and direct — many users have low literacy or use screen readers.
3. Mention the official government portal and helpline number.
4. Cite the source naturally: "Retrieved from Government of India S3 document store via RAG"
5. If user writes in Hindi/regional language, reply in that language.
6. Keep responses complete but concise.

${langObj.prompt}`
}

/**
 * Amazon Cognito — simulated auth check
 * In production: AWS Cognito User Pool validates JWT token
 */
export function getCognitoSession() {
  return { userId: 'citizen_' + Math.random().toString(36).substr(2, 8), region: 'ap-south-1' }
}

/**
 * Amazon DynamoDB — simulated session logger
 * In production: Lambda writes to DynamoDB table "genseva-sessions"
 */
export function logToDynamoDB(sessionId, userQuery, botResponse) {
  console.log('[DynamoDB] Session:', sessionId, '| Query logged at', new Date().toISOString())
}

/**
 * Amazon Transcribe (STT) — Web Speech API for prototype
 * In production: Audio stream → Amazon Transcribe → text
 */
export function startTranscribe(lang, onResult, onEnd, onError) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition
  if (!SR) { onError('not-supported'); return null }

  const langObj = LANGUAGES.find(l => l.code === lang) || LANGUAGES[0]
  const r = new SR()
  r.lang = langObj.apiLang
  r.interimResults = false
  r.onresult = e => onResult(e.results[0][0].transcript)
  r.onend = onEnd
  r.onerror = e => onError(e.error)
  r.start()
  return r
}

/**
 * Amazon Polly (TTS) — Web Speech Synthesis for prototype
 * In production: Text → Amazon Polly → audio stream
 */
export function speakWithPolly(text, lang) {
  if (!window.speechSynthesis) return
  window.speechSynthesis.cancel()
  const u = new SpeechSynthesisUtterance(text.replace(/\*\*(.*?)\*\*/g, '$1').substring(0, 400))
  u.lang = lang === 'en' ? 'en-IN' : lang + '-IN'
  u.rate = 0.88
  window.speechSynthesis.speak(u)
}
