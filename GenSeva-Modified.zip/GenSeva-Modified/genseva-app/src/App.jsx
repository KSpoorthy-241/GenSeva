import { useState } from 'react'
import { Routes, Route } from 'react-router-dom'
import Navbar      from './components/Navbar'
import LangBar     from './components/LangBar'
import Footer      from './components/Footer'
import Home        from './pages/Home'
import Chat        from './pages/Chat'
import Schemes     from './pages/Schemes'
import Eligibility from './pages/Eligibility'
import Alerts      from './pages/Alerts'

export default function App() {
  const [lang, setLang] = useState('en')

  return (
    <div className="min-h-screen text-gray-800 font-sans flex flex-col" style={{background:'#fefde8'}}>
      <Navbar lang={lang} setLang={setLang} />
      <LangBar lang={lang} setLang={setLang} />
      <main className="flex-1">
        <Routes>
          <Route path="/"            element={<Home lang={lang} />} />
          <Route path="/chat"        element={<Chat lang={lang} />} />
          <Route path="/schemes"     element={<Schemes lang={lang} />} />
          <Route path="/eligibility" element={<Eligibility lang={lang} />} />
          <Route path="/alerts"      element={<Alerts lang={lang} />} />
          <Route path="*"            element={<Home lang={lang} />} />
        </Routes>
      </main>
      <Footer lang={lang} />
    </div>
  )
}
