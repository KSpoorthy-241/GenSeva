import { useState, useRef, useEffect, useCallback } from 'react'
import { SCHEMES, LANGUAGES } from '../data/schemes'
import { callClaude, formatMarkdown, getTime } from '../utils/api'
import T from '../data/translations'

const QUICK_PROMPTS = [
  'Am I eligible for PM-KISAN as a farmer?',
  'Documents needed for Ayushman Bharat card?',
  'Steps to apply for Mudra Loan?',
  'Schemes for women entrepreneurs in India',
  'Benefits for senior citizens above 60',
  'Education schemes for SC/ST students',
]

const SIDEBAR_SCHEMES = [
  'PM-KISAN','Ayushman Bharat','PM Awas Yojana','Mudra Loan',
  'Sukanya Samriddhi','MGNREGS','Atal Pension','PM Ujjwala 2.0',
  'Kisan Credit Card','PM Scholarship',
]

export default function Chat({ lang }) {
  const t = T[lang] || T.en
  const [messages, setMessages] = useState([{
    id: 1, role: 'bot', time: getTime(), text: t.chatWelcome
  }])
  const [input, setInput]     = useState('')
  const [loading, setLoading] = useState(false)
  const [recording, setRecording] = useState(false)
  const [history, setHistory] = useState([])
  const bottomRef  = useRef(null)
  const recRef     = useRef(null)
  const taRef      = useRef(null)

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior:'smooth' }) }, [messages, loading])

  const send = useCallback(async (override) => {
    const text = (override || input).trim()
    if (!text || loading) return
    setInput('')
    if (taRef.current) taRef.current.style.height = 'auto'
    setLoading(true)
    const userMsg = { id: Date.now(), role:'user', time:getTime(), text }
    setMessages(p => [...p, userMsg])
    const newHistory = [...history, { role:'user', content:text }]
    setHistory(newHistory)
    try {
      const reply = await callClaude(newHistory, lang)
      setMessages(p => [...p, { id:Date.now()+1, role:'bot', time:getTime(), text:reply }])
      setHistory(p => [...p, { role:'assistant', content:reply }])
    } catch(e) {
      setMessages(p => [...p, { id:Date.now()+1, role:'bot', time:getTime(), text:`⚠️ ${e.message}. Please try again.` }])
    }
    setLoading(false)
  }, [input, loading, history, lang])

  const toggleMic = () => {
    if (recording) { recRef.current?.stop(); setRecording(false); return }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SR) { const demos=['Tell me about PM-KISAN eligibility','Documents for Ayushman Bharat','How to apply for Mudra Loan?']; const tx=demos[Math.floor(Math.random()*3)]; setInput(tx); setTimeout(()=>send(tx),400); return }
    const r = new SR()
    recRef.current = r
    r.lang = LANGUAGES.find(l=>l.code===lang)?.apiLang || 'en-IN'
    r.onstart  = () => setRecording(true)
    r.onresult = e => { send(e.results[0][0].transcript) }
    r.onend    = () => setRecording(false)
    r.onerror  = () => setRecording(false)
    r.start()
  }

  return (
    <div className="flex" style={{height:'calc(100vh - 108px)'}}>

      {/* Sidebar */}
      <aside className="hidden lg:flex flex-col w-48 shrink-0 border-r border-green-300 overflow-y-auto" style={{background:'rgba(255,255,255,0.5)'}}>
        <div className="p-3">
          <p className="text-[10px] text-green-700/60 uppercase tracking-widest mb-2 font-bold">{t.quickSchemes}</p>
          {SIDEBAR_SCHEMES.map(s => (
            <button key={s} onClick={() => send(`Tell me about ${s}: eligibility, benefits, documents and how to apply.`)}
              className="w-full text-left text-xs text-green-800 hover:text-green-900 px-2.5 py-1.5 rounded-lg hover:bg-green-200 transition-all mb-0.5 font-medium">
              📌 {s}
            </button>
          ))}
        </div>
      </aside>

      {/* Main chat */}
      <div className="flex flex-col flex-1 min-w-0">

        {/* Header */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-orange-300 shrink-0" style={{background:'linear-gradient(90deg,#ea580c,#f97316)'}}>
          <div className="w-9 h-9 rounded-full border-2 border-white/30 flex items-center justify-center text-base shrink-0 bg-white/20">🤖</div>
          <div className="min-w-0">
            <div className="text-sm font-bold text-white">GenSeva AI Assistant</div>
            <div className="text-xs text-white/65 truncate">Powered by Groq AI · Llama 3.3 70B</div>
          </div>
          <button onClick={toggleMic}
            className={`ml-auto flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full border shrink-0 transition-all font-semibold ${recording ? 'bg-red-500 border-red-400 text-white' : 'bg-white/20 border-white/30 text-white hover:bg-white/30'}`}>
            {recording ? t.stopBtn : t.voiceBtn}
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-3" style={{background:'#fefde8'}}>
          {messages.map(m => (
            <div key={m.id} className={`flex gap-2.5 ${m.role==='user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm shrink-0 mt-0.5 ${m.role==='user' ? 'bg-green-600' : 'bg-green-700'} text-white`}>
                {m.role==='user' ? '👤' : '🤖'}
              </div>
              <div className={`max-w-xs md:max-w-lg flex flex-col ${m.role==='user' ? 'items-end' : 'items-start'}`}>
                <div className={`px-4 py-3 text-sm leading-relaxed rounded-2xl shadow-sm ${
                  m.role==='user'
                    ? 'text-white rounded-br-sm'
                    : 'text-gray-800 rounded-bl-sm border border-green-300'
                }`} style={m.role==='user'
                    ? {background:'linear-gradient(135deg,#ea580c,#f97316)'}
                    : {background:'rgba(255,255,255,0.85)'}
                  }
                  dangerouslySetInnerHTML={{ __html: m.role==='bot' ? formatMarkdown(m.text) : m.text }}
                />
                <span className="text-xs text-green-700/40 mt-1 px-1">{m.time}</span>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-2.5">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm bg-green-700 text-white shrink-0">🤖</div>
              <div className="px-4 py-3 rounded-2xl rounded-bl-sm border border-green-300 flex items-center gap-3" style={{background:'rgba(255,255,255,0.85)'}}>
                <div className="flex gap-1.5">
                  {[0,1,2].map(i => <div key={i} className="w-2 h-2 rounded-full bg-green-500 animate-bounce" style={{animationDelay:`${i*0.15}s`}} />)}
                </div>
                <span className="text-xs text-green-600">Thinking…</span>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Quick prompts */}
        <div className="px-4 py-2 flex gap-2 flex-wrap border-t border-green-300 shrink-0" style={{background:'rgba(255,255,255,0.4)'}}>
          {QUICK_PROMPTS.map(q => (
            <button key={q} onClick={() => send(q)}
              className="text-xs px-3 py-1.5 rounded-full border border-green-400 text-green-700 hover:bg-green-600 hover:text-white transition-all font-medium" style={{background:'rgba(255,255,255,0.7)'}}>
              {q}
            </button>
          ))}
        </div>

        {/* Input */}
        <div className="px-4 py-3 border-t border-green-300 shrink-0" style={{background:'rgba(255,255,255,0.5)'}}>
          <div className="flex gap-2 items-end">
            <button onClick={toggleMic}
              className={`w-11 h-11 rounded-xl flex items-center justify-center text-lg border shrink-0 transition-all ${recording ? 'bg-red-500 border-red-400 text-white' : 'border-green-400 text-green-700 hover:bg-green-200'}`}
              style={recording ? {} : {background:'rgba(255,255,255,0.7)'}}>
              🎤
            </button>
            <textarea ref={taRef} value={input}
              onChange={e => { setInput(e.target.value); e.target.style.height='auto'; e.target.style.height=Math.min(e.target.scrollHeight,120)+'px' }}
              onKeyDown={e => { if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()} }}
              placeholder={t.chatPlaceholder} rows={1}
              style={{minHeight:'44px',maxHeight:'120px',resize:'none',background:'rgba(255,255,255,0.85)'}}
              className="flex-1 border border-green-400 rounded-xl px-4 py-2.5 text-sm text-gray-800 placeholder-green-600/40 outline-none focus:border-green-600 transition-colors"
            />
            <button onClick={() => send()}
              className="w-11 h-11 rounded-xl flex items-center justify-center shadow-lg shrink-0 hover:-translate-y-0.5 transition-all"
              style={{background:'linear-gradient(135deg,#ea580c,#f97316)'}}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
            </button>
          </div>
          <p className="text-xs text-center mt-2 text-green-700/40">{t.chatFooter}</p>
        </div>
      </div>
    </div>
  )
}
