import { useState } from 'react'
import { ALERTS } from '../data/schemes'
import T from '../data/translations'

const COLOR = {
  yellow: { ring:'border-yellow-400 bg-yellow-50', title:'text-yellow-700', badge:'bg-yellow-100 text-yellow-700 border-yellow-300' },
  teal:   { ring:'border-teal-400 bg-teal-50',     title:'text-teal-700',   badge:'bg-teal-100 text-teal-700 border-teal-300' },
  blue:   { ring:'border-blue-400 bg-blue-50',     title:'text-blue-700',   badge:'bg-blue-100 text-blue-700 border-blue-300' },
  green:  { ring:'border-green-400 bg-green-50',   title:'text-green-700',  badge:'bg-green-100 text-green-700 border-green-300' },
  orange: { ring:'border-orange-400 bg-orange-50', title:'text-orange-700', badge:'bg-orange-100 text-orange-700 border-orange-300' },
}

export default function Alerts({ lang }) {
  const [dismissed, setDismissed] = useState([])
  const t = T[lang] || T.en
  const active = ALERTS.filter(a => !dismissed.includes(a.id))

  return (
    <div className="min-h-screen px-4 py-8" style={{background:'#fefde8'}}>
      <div className="max-w-3xl mx-auto">

        <h1 className="text-2xl font-bold mb-1 flex items-center gap-2" style={{color:'#14532d'}}>
          {t.alertsTitle}
          {active.length > 0 && (
            <span className="text-xs bg-red-500 text-white rounded-full px-2 py-0.5 font-bold">{active.length}</span>
          )}
        </h1>
        <p className="text-green-700/60 text-sm mb-6">{t.alertsDesc}</p>

        {active.length === 0 ? (
          <div className="text-center py-20 rounded-2xl border border-green-300" style={{background:'rgba(255,255,255,0.65)'}}>
            <div className="text-5xl mb-4">✅</div>
            <div className="text-green-700 text-sm">{t.allCaughtUp}</div>
          </div>
        ) : (
          <div className="flex flex-col gap-4 mb-8">
            {active.map(a => {
              const c = COLOR[a.color]
              return (
                <div key={a.id} className={`border-2 ${c.ring} rounded-2xl p-5 shadow-sm`}>
                  <div className="flex items-start gap-4">
                    <div className="text-2xl shrink-0 mt-0.5">{a.icon}</div>
                    <div className="flex-1 min-w-0">
                      <div className={`text-base font-bold ${c.title} mb-1`}>{a.title}</div>
                      <div className="text-sm text-gray-600 leading-relaxed mb-3">{a.desc}</div>
                      <div className="flex items-center gap-3 flex-wrap">
                        <span className={`text-xs px-3 py-1 rounded-full border font-medium ${c.badge}`}>📅 {a.date}</span>
                        <button onClick={() => setDismissed(p => [...p, a.id])}
                          className="text-xs text-gray-400 hover:text-red-500 transition-colors">
                          {t.dismiss}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Notification Preferences — clean, no tech stack mention */}
        <div className="rounded-2xl p-6 border border-green-300 shadow-sm" style={{background:'rgba(255,255,255,0.65)'}}>
          <h3 className="text-sm font-bold text-green-900 mb-4">{t.notifTitle}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {t.notifPrefs.map(p => (
              <label key={p} className="flex items-center gap-3 cursor-pointer group">
                <div className="w-9 h-5 bg-green-500 rounded-full relative shrink-0">
                  <div className="w-4 h-4 bg-white rounded-full absolute top-0.5 right-0.5 shadow" />
                </div>
                <span className="text-xs text-green-800 group-hover:text-green-900 transition-colors font-medium">{p}</span>
              </label>
            ))}
          </div>
        </div>

      </div>
    </div>
  )
}
