import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import T from '../data/translations'

const SCHEME_CARDS = [
  { icon:'🌾', name:'PM-KISAN', benefit:'₹6,000/year', tag:'Agriculture', color:'#dcfce7', border:'#86efac' },
  { icon:'🏥', name:'Ayushman Bharat', benefit:'₹5L health cover', tag:'Health', color:'#dbeafe', border:'#93c5fd' },
  { icon:'🏠', name:'PM Awas Yojana', benefit:'₹2.5L subsidy', tag:'Housing', color:'#fef9c3', border:'#fde047' },
  { icon:'💼', name:'Mudra Loan', benefit:'Up to ₹10L', tag:'Business', color:'#fce7f3', border:'#f9a8d4' },
  { icon:'👧', name:'Sukanya Samriddhi', benefit:'7.6% interest', tag:'Women', color:'#ede9fe', border:'#c4b5fd' },
  { icon:'🔨', name:'MGNREGS', benefit:'100 days/yr', tag:'Employment', color:'#ffedd5', border:'#fdba74' },
  { icon:'🌱', name:'Fasal Bima', benefit:'Crop insurance', tag:'Agriculture', color:'#dcfce7', border:'#86efac' },
  { icon:'🔥', name:'PM Ujjwala 2.0', benefit:'Free LPG', tag:'BPL/Women', color:'#fee2e2', border:'#fca5a5' },
]

const PORTAL_LINKS = [
  { icon:'🏛️', name:'myScheme', url:'myscheme.gov.in', desc:'Find all schemes' },
  { icon:'📱', name:'UMANG', url:'umang.gov.in', desc:'1500+ govt services' },
  { icon:'🌾', name:'PM-KISAN', url:'pmkisan.gov.in', desc:'Farmer portal' },
  { icon:'🏥', name:'Ayushman', url:'pmjay.gov.in', desc:'Health card' },
  { icon:'🎓', name:'Scholarships', url:'scholarships.gov.in', desc:'National portal' },
  { icon:'🏠', name:'PMAY', url:'pmaymis.gov.in', desc:'Housing scheme' },
]

const MARQUEE_ITEMS = [
  '🏥 Ayushman Bharat — ₹5L Health Cover',
  '🏠 PM Awas Yojana — ₹2.5L Housing',
  '💼 Mudra Loan — Up to ₹10L',
  '👧 Sukanya Samriddhi — 7.6%',
  '🌾 PM-KISAN — ₹6,000/year',
  '🔨 MGNREGS — 100 days/yr',
  '🔥 PM Ujjwala 2.0 — Free LPG',
  '🎓 NSP Scholarship — Education Aid',
]

export default function Home({ lang }) {
  const navigate = useNavigate()
  const t = T[lang] || T.en
  const [searchVal, setSearchVal] = useState('')

  const filtered = SCHEME_CARDS.filter(s =>
    s.name.toLowerCase().includes(searchVal.toLowerCase()) ||
    s.tag.toLowerCase().includes(searchVal.toLowerCase()) ||
    s.benefit.toLowerCase().includes(searchVal.toLowerCase())
  )

  return (
    <div className="min-h-screen" style={{background:'#fefde8'}}>

      {/* ── Hero ── */}
      <section className="px-4 pt-14 pb-10 text-center">
        <div className="max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-semibold mb-5 border"
            style={{background:'rgba(255,255,255,0.6)', color:'#15803d', borderColor:'#86efac'}}>
            🇮🇳 AWS AI for Bharat Hackathon · Team Alkya
          </div>
          {/* Bicolor hero title */}
          <h1 className="text-6xl md:text-7xl font-extrabold mb-1 tracking-tight" style={{fontFamily:'Sora,sans-serif'}}>
            <span style={{color:'#1a2e1a'}}>Gen</span><span style={{color:'#f97316'}}>Seva</span>
          </h1>
          <h2 className="text-2xl md:text-3xl font-bold mb-1" style={{color:'#15803d'}}>
            {t.heroSub}
          </h2>
          <h3 className="text-lg font-semibold mb-5" style={{color:'#f97316'}}>
            {t.heroLang}
          </h3>
          <p className="text-sm text-green-800/65 max-w-lg mx-auto mb-7 leading-relaxed">{t.heroDesc}</p>
          <div className="flex flex-wrap gap-3 justify-center">
            {/* Start Chatting — orange/saffron */}
            <button onClick={() => navigate('/chat')}
              className="px-7 py-3 rounded-xl text-white font-bold text-sm shadow-lg transition-all hover:-translate-y-0.5"
              style={{background:'linear-gradient(135deg,#ea580c,#f97316)', boxShadow:'0 4px 18px rgba(234,88,12,0.35)'}}>
              💬 {t.btnChat}
            </button>
            {/* Check Eligibility — dark green */}
            <button onClick={() => navigate('/eligibility')}
              className="px-7 py-3 rounded-xl font-bold text-sm text-white transition-all hover:-translate-y-0.5"
              style={{background:'linear-gradient(135deg,#15803d,#14532d)', boxShadow:'0 4px 16px rgba(21,128,61,0.3)'}}>
              ✅ {t.btnEligibility}
            </button>
            {/* Browse Schemes — outlined */}
            <button onClick={() => navigate('/schemes')}
              className="px-7 py-3 rounded-xl font-bold text-sm border-2 text-gray-700 hover:text-orange-700 transition-all"
              style={{background:'rgba(255,255,255,0.85)', borderColor:'#d1d5db'}}>
              📋 {t.btnSchemes}
            </button>
          </div>
        </div>
      </section>

      {/* ── Marquee Ticker ── */}
      <div className="overflow-hidden py-2.5 border-y border-orange-200" style={{background:'rgba(255,255,255,0.5)'}}>
        <style>{`
          @keyframes marquee { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
          .marquee-track { display:flex; width:max-content; animation:marquee 28s linear infinite; }
          .marquee-track:hover { animation-play-state:paused; }
        `}</style>
        <div className="marquee-track">
          {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((item, i) => (
            <span key={i} className="inline-flex items-center gap-1.5 px-5 text-xs font-semibold whitespace-nowrap"
              style={{color: i % 4 === 0 ? '#f97316' : '#15803d'}}>
              <span className="w-2 h-2 rounded-full inline-block" style={{background: i % 4 === 0 ? '#f97316' : '#16a34a'}} />
              {item}
            </span>
          ))}
        </div>
      </div>

      {/* ── Stats ── */}
      <section className="px-4 pb-8">
        <div className="max-w-3xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            {icon:'📋', val:t.stat1},
            {icon:'🌐', val:t.stat2},
            {icon:'💚', val:t.stat3},
            {icon:'👥', val:t.stat4},
          ].map((s,i) => (
            <div key={i} className="rounded-xl p-4 text-center border border-green-300 hover:-translate-y-1 transition-all"
              style={{background:'rgba(255,255,255,0.65)'}}>
              <div className="text-xl mb-1">{s.icon}</div>
              <div className="text-sm font-bold text-green-900">{s.val}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Interactive Scheme Explorer ── */}
      <section className="px-4 pb-8">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-xl font-extrabold text-center mb-2" style={{color:'#14532d'}}>{t.intTitle}</h2>

          {/* Search bar */}
          <div className="relative max-w-lg mx-auto mb-6">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-green-500">🔍</span>
            <input
              value={searchVal}
              onChange={e => setSearchVal(e.target.value)}
              placeholder={t.intSearchPlaceholder}
              className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-green-400 text-sm text-gray-800 font-medium outline-none focus:border-green-600 transition-colors"
              style={{background:'rgba(255,255,255,0.85)'}}
            />
          </div>

          {/* Scheme cards grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            {(searchVal ? filtered : SCHEME_CARDS).map((s,i) => (
              <button key={i} onClick={() => navigate('/schemes')}
                className="text-left p-4 rounded-2xl border-2 hover:-translate-y-1 hover:shadow-md transition-all"
                style={{background:s.color, borderColor:s.border}}>
                <div className="text-2xl mb-2">{s.icon}</div>
                <div className="text-sm font-extrabold text-green-950 mb-0.5">{s.name}</div>
                <div className="text-xs text-green-700 font-medium mb-2">{s.tag}</div>
                <div className="text-xs font-bold px-2 py-0.5 rounded-full inline-block"
                  style={{background:'rgba(255,255,255,0.7)', color:'#15803d', border:'1px solid rgba(22,163,74,0.3)'}}>
                  💰 {s.benefit}
                </div>
              </button>
            ))}
            {searchVal && filtered.length === 0 && (
              <div className="col-span-4 text-center py-8 text-green-700/50 text-sm">
                No schemes found. Try a different keyword.
              </div>
            )}
          </div>

          {/* Quick link chips */}
          <div className="flex flex-wrap gap-2 justify-center mb-2">
            {t.quickLinks.map((ql,i) => (
              <button key={i} onClick={() => navigate('/chat')}
                className="px-3 py-1.5 rounded-full text-xs font-semibold border border-green-400 text-green-700 hover:bg-green-600 hover:text-white hover:border-green-600 transition-all"
                style={{background:'rgba(255,255,255,0.7)'}}>
                {ql}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── Govt Portals ── */}
      <section className="px-4 pb-8">
        <div className="max-w-4xl mx-auto rounded-2xl p-6 border border-green-300" style={{background:'rgba(255,255,255,0.6)'}}>
          <h3 className="text-sm font-extrabold text-green-900 mb-4 text-center">🔗 Official Government Portals</h3>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
            {PORTAL_LINKS.map((p,i) => (
              <div key={i} className="flex flex-col items-center text-center p-3 rounded-xl hover:-translate-y-1 transition-all cursor-pointer border border-green-200"
                style={{background:'rgba(255,255,255,0.7)'}}>
                <div className="text-2xl mb-1">{p.icon}</div>
                <div className="text-xs font-bold text-green-900">{p.name}</div>
                <div className="text-[9px] text-green-600/70 mt-0.5">{p.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="px-4 pb-14 text-center">
        <div className="max-w-md mx-auto rounded-2xl p-8 border border-green-400 shadow"
          style={{background:'rgba(255,255,255,0.65)'}}>
          <div className="text-4xl mb-3">🙏</div>
          <h3 className="text-xl font-extrabold mb-2" style={{color:'#14532d'}}>{t.ctaTitle}</h3>
          <p className="text-green-700/65 text-sm mb-5">{t.ctaDesc}</p>
          <button onClick={() => navigate('/chat')}
            className="px-10 py-3 rounded-xl text-white font-bold hover:-translate-y-0.5 transition-all"
            style={{background:'linear-gradient(135deg,#ea580c,#f97316)', boxShadow:'0 4px 16px rgba(234,88,12,0.3)'}}>
            {t.ctaBtn}
          </button>
        </div>
      </section>
    </div>
  )
}
