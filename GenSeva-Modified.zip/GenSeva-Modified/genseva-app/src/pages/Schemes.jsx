import { useState } from 'react'
import { SCHEMES, STATE_SCHEMES } from '../data/schemes'
import { callClaude, formatMarkdown } from '../utils/api'
import T from '../data/translations'

const CATS = ['All','Agriculture','Health','Housing','Business','Women','Education','Employment','Insurance','Pension']
const STATES = ['Karnataka','Telangana','Tamil Nadu','Andhra Pradesh','Maharashtra','Uttar Pradesh','West Bengal','Gujarat','Rajasthan','Madhya Pradesh']

export default function Schemes({ lang }) {
  const t = T[lang] || T.en
  const [cat, setCat]       = useState('All')
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)
  const [detail, setDetail] = useState('')
  const [loading, setLoading] = useState(false)
  const [stateSchemes, setStateSchemes] = useState([])

  const filtered = SCHEMES.filter(s =>
    (cat==='All' || s.cat===cat) &&
    s.name.toLowerCase().includes(search.toLowerCase())
  )

  const loadDetail = async (scheme) => {
    setSelected(scheme)
    setDetail('')
    setLoading(true)
    try {
      const reply = await callClaude([{role:'user',content:`Tell me about ${scheme.name}: Overview, Eligibility, Benefits (exact amounts), Required Documents, Step-by-step application, Official portal.`}], lang)
      setDetail(reply)
    } catch(e) { setDetail('⚠️ Could not load details. Please try again.') }
    setLoading(false)
  }

  const loadStateScheme = async (name) => {
    setSelected({name, icon:'📌', cat:'State Scheme'})
    setDetail('')
    setLoading(true)
    try {
      const reply = await callClaude([{role:'user',content:`Tell me about the ${name} state scheme in India: Overview, Eligibility, Benefits, Documents, How to apply.`}], lang)
      setDetail(reply)
    } catch(e) { setDetail('⚠️ Could not load details.') }
    setLoading(false)
  }

  return (
    <div className="min-h-screen px-4 py-8" style={{background:'#fefde8'}}>
      <div className="max-w-6xl mx-auto">
        <h1 className="text-2xl font-bold mb-1" style={{color:'#14532d'}}>{t.schemesTitle}</h1>
        <p className="text-green-700/60 text-sm mb-5">{t.schemesDesc}</p>

        <div className="flex flex-wrap gap-3 mb-4">
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder={t.searchPlaceholder}
            className="flex-1 min-w-48 border border-green-400 rounded-xl px-4 py-2.5 text-sm text-gray-800 placeholder-green-600/40 outline-none focus:border-green-600"
            style={{background:'rgba(255,255,255,0.8)'}} />
        </div>

        <div className="flex gap-2 flex-wrap mb-4">
          {CATS.map(c => (
            <button key={c} onClick={() => setCat(c)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${cat===c ? 'bg-green-600 text-white border-green-600 shadow' : 'border-green-400 text-green-700 hover:bg-green-200'}`}
              style={cat===c ? {} : {background:'rgba(255,255,255,0.7)'}}>
              {c}
            </button>
          ))}
        </div>

        {/* State filter */}
        <div className="mb-5 rounded-2xl p-4 border border-green-300 shadow-sm" style={{background:'rgba(255,255,255,0.6)'}}>
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-sm text-green-800 font-semibold shrink-0">{t.stateSchemes}</span>
            <select onChange={e => {
              const ss = STATE_SCHEMES[e.target.value] || []
              setStateSchemes(ss)
            }} className="border border-green-400 rounded-lg px-3 py-2 text-sm text-green-800 outline-none flex-1 max-w-xs font-medium"
              style={{background:'rgba(255,255,255,0.8)'}}>
              <option value="">{t.selectState}</option>
              {STATES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          {stateSchemes.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {stateSchemes.map(s => (
                <button key={s.name} onClick={() => loadStateScheme(s.name)}
                  className="px-3 py-1.5 text-xs rounded-full border border-green-500 text-green-700 hover:bg-green-600 hover:text-white transition-all font-medium"
                  style={{background:'rgba(255,255,255,0.7)'}}>
                  📌 {s.name} · {s.benefit}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Two columns */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-5">
          <div className="md:col-span-2 flex flex-col gap-2.5 overflow-y-auto pr-1" style={{maxHeight:'580px'}}>
            {filtered.map(s => (
              <button key={s.id} onClick={() => loadDetail(s)}
                className={`text-left border rounded-xl p-4 transition-all hover:-translate-y-0.5 shadow-sm w-full ${selected?.id===s.id ? 'border-green-600 shadow-md' : 'border-green-300 hover:border-green-500'}`}
                style={{background: selected?.id===s.id ? 'rgba(255,255,255,0.9)' : 'rgba(255,255,255,0.65)'}}>
                <div className="flex items-start gap-3">
                  <div className="text-2xl shrink-0">{s.icon}</div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-bold text-green-900">{s.name}</div>
                    <div className="text-xs text-green-600/70 mt-0.5">{s.cat}</div>
                    <div className="mt-2 inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold border border-green-400 text-green-700" style={{background:'rgba(255,255,255,0.8)'}}>
                      💰 {s.benefit}
                    </div>
                  </div>
                  <div className="text-green-400 text-lg self-center">›</div>
                </div>
              </button>
            ))}
          </div>

          <div className="md:col-span-3 rounded-2xl p-6 border border-green-300 sticky top-24 self-start shadow-sm" style={{background:'rgba(255,255,255,0.75)'}}>
            {!selected ? (
              <div className="flex flex-col items-center justify-center text-center" style={{height:'280px'}}>
                <div className="text-5xl mb-3">📋</div>
                <div className="text-sm text-green-700/50">{t.selectScheme}</div>
              </div>
            ) : (
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="text-3xl">{selected.icon}</div>
                  <div>
                    <div className="text-base font-bold text-green-900">{selected.name}</div>
                    <div className="text-xs text-green-600">{selected.cat}</div>
                  </div>
                </div>
                {loading ? (
                  <div className="space-y-2">
                    {[100,80,100,65,90].map((w,i) => (
                      <div key={i} className="h-3 rounded bg-green-200 animate-pulse" style={{width:`${w}%`}} />
                    ))}
                    <div className="text-xs text-green-600 mt-2">Loading details…</div>
                  </div>
                ) : (
                  <div className="text-sm leading-relaxed overflow-y-auto text-gray-700" style={{maxHeight:'360px'}}
                    dangerouslySetInnerHTML={{ __html: formatMarkdown(detail) }} />
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
