import { useState } from 'react'
import { callClaude, formatMarkdown } from '../utils/api'
import T from '../data/translations'

export default function Eligibility({ lang }) {
  const t = T[lang] || T.en
  const [form, setForm] = useState({ income:'', occ:'', gender:'', cat:'', age:'', state:'' })
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)

  const set = (k,v) => setForm(p => ({...p,[k]:v}))

  const check = async () => {
    if (!form.income || !form.occ) { alert('Please select at least income and occupation.'); return }
    setLoading(true); setResult('')
    try {
      const reply = await callClaude([{role:'user',content:`Citizen profile — Income: ${form.income}, Occupation: ${form.occ}, Gender: ${form.gender||'not specified'}, Category: ${form.cat||'not specified'}, Age: ${form.age||'not specified'}, State: ${form.state||'not specified'}. List 5-6 most relevant Indian government schemes they qualify for. For each: name, key benefit, why they qualify, critical document, official portal. Be warm and encouraging. IMPORTANT: Respond entirely in the language specified in the system prompt.`}], lang)
      setResult(reply)
    } catch(e) { setResult('⚠️ Unable to check. Please try again.') }
    setLoading(false)
  }

  const sel = (label, key, opts) => (
    <div>
      <label className="block text-xs font-bold text-green-800 mb-1.5">{label}</label>
      <select value={form[key]} onChange={e=>set(key,e.target.value)}
        className="w-full border border-green-400 rounded-xl px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-green-600 transition-colors"
        style={{background:'rgba(255,255,255,0.8)'}}>
        <option value="">—</option>
        {opts.map(([v,l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </div>
  )

  return (
    <div className="min-h-screen px-4 py-8" style={{background:'#fefde8'}}>
      <div className="max-w-5xl mx-auto">
        <h1 className="text-2xl font-bold mb-1" style={{color:'#14532d'}}>{t.eligTitle}</h1>
        <p className="text-green-700/60 text-sm mb-7">{t.eligDesc}</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Form */}
          <div className="rounded-2xl p-6 border border-green-300 shadow-sm" style={{background:'rgba(255,255,255,0.7)'}}>
            <div className="flex flex-col gap-4">
              {sel(t.income, 'income', [['below1','Below ₹1 Lakh'],['1to2','₹1–2 Lakh'],['2to5','₹2–5 Lakh'],['5to10','₹5–10 Lakh'],['above10','Above ₹10 Lakh']])}
              {sel(t.occupation, 'occ', [['farmer','Farmer / Agriculture'],['labor','Daily Wage Laborer'],['business','Small Business Owner'],['women','Women Entrepreneur'],['student','Student'],['senior','Senior Citizen (60+)'],['disabled','Differently Abled']])}
              {sel(t.gender, 'gender', [['male','Male'],['female','Female'],['other','Prefer not to say']])}
              {sel(t.category, 'cat', [['general','General'],['obc','OBC'],['sc','SC / Dalit'],['st','ST / Tribal'],['ews','EWS']])}
              <div>
                <label className="block text-xs font-bold text-green-800 mb-1.5">{t.age}</label>
                <input type="number" value={form.age} onChange={e=>set('age',e.target.value)} placeholder="e.g. 35"
                  className="w-full border border-green-400 rounded-xl px-3 py-2.5 text-sm text-gray-800 outline-none focus:border-green-600"
                  style={{background:'rgba(255,255,255,0.8)'}} />
              </div>
              {sel(t.state, 'state', [['ap','Andhra Pradesh'],['tn','Tamil Nadu'],['mh','Maharashtra'],['up','Uttar Pradesh'],['ka','Karnataka'],['wb','West Bengal'],['gj','Gujarat'],['ts','Telangana'],['rj','Rajasthan'],['mp','Madhya Pradesh'],['other','Other']])}
            </div>
            <button onClick={check} disabled={loading}
              className="mt-5 w-full py-3 rounded-xl text-white font-bold hover:-translate-y-0.5 transition-all disabled:opacity-60 shadow"
              style={{background:'linear-gradient(135deg,#ea580c,#f97316)'}}>
              {loading ? t.eligChecking : t.eligBtn}
            </button>
          </div>

          {/* Result */}
          <div className="rounded-2xl p-6 flex flex-col border border-green-300 shadow-sm" style={{background:'rgba(255,255,255,0.7)'}}>
            <h2 className="text-sm font-bold text-green-900 mb-4">{t.matchedSchemes}</h2>
            {loading ? (
              <div className="flex-1 space-y-2">
                {[100,80,100,65,90,100].map((w,i)=>(
                  <div key={i} className="h-3 rounded bg-green-200 animate-pulse" style={{width:`${w}%`}}/>
                ))}
                <div className="text-xs text-green-600 mt-2">Matching schemes…</div>
              </div>
            ) : result ? (
              <div className="flex-1 overflow-y-auto text-sm leading-relaxed text-gray-700"
                dangerouslySetInnerHTML={{ __html: formatMarkdown(result) }} />
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center py-8">
                <div className="text-5xl mb-4">🔍</div>
                <div className="text-sm text-green-700/50">{t.eligResult}</div>
              </div>
            )}
          </div>
        </div>

        {/* Tips */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {icon:'📄',title:t.tip1Title,desc:t.tip1Desc},
            {icon:'📱',title:t.tip2Title,desc:t.tip2Desc},
            {icon:'🏛️',title:t.tip3Title,desc:t.tip3Desc},
          ].map((tip,i) => (
            <div key={i} className="rounded-xl p-4 border border-green-300 shadow-sm" style={{background:'rgba(255,255,255,0.65)'}}>
              <div className="text-xl mb-2">{tip.icon}</div>
              <div className="text-sm font-bold text-green-900 mb-1">{tip.title}</div>
              <div className="text-xs text-green-700/65">{tip.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
