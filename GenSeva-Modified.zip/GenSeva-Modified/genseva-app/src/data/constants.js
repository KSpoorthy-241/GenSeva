// ──────────────────────────────────────────────────────
//  GenSeva AI — Central Data Store
// ──────────────────────────────────────────────────────

export const LANGUAGES = [
  { code: 'en', label: 'English',   apiLang: 'en-IN', prompt: 'Respond in clear, simple English. Use easy vocabulary.' },
  { code: 'hi', label: 'हिंदी',      apiLang: 'hi-IN', prompt: 'पूरा उत्तर हिंदी में देवनागरी लिपि में दें। सरल भाषा उपयोग करें।' },
  { code: 'ta', label: 'தமிழ்',      apiLang: 'ta-IN', prompt: 'முழு பதிலையும் தமிழில் கொடுங்கள். எளிய மொழியில் விளக்குங்கள்.' },
  { code: 'te', label: 'తెలుగు',     apiLang: 'te-IN', prompt: 'మొత్తం సమాధానం తెలుగులో ఇవ్వండి. సులభమైన భాష ఉపయోగించండి.' },
  { code: 'bn', label: 'বাংলা',      apiLang: 'bn-IN', prompt: 'সম্পূর্ণ উত্তর বাংলায় দিন। সহজ ভাষা ব্যবহার করুন।' },
  { code: 'mr', label: 'मराठी',      apiLang: 'mr-IN', prompt: 'संपूर्ण उत्तर मराठीत द्या. सोपी भाषा वापरा.' },
  { code: 'kn', label: 'ಕನ್ನಡ',     apiLang: 'kn-IN', prompt: 'ಸಂಪೂರ್ಣ ಉತ್ತರವನ್ನು ಕನ್ನಡದಲ್ಲಿ ನೀಡಿ. ಸರಳ ಭಾಷೆ ಬಳಸಿ.' },
  { code: 'gu', label: 'ગુજરાતી',   apiLang: 'gu-IN', prompt: 'સંપૂર્ણ જવાબ ગુજરાતીમાં આપો. સરળ ભાષાનો ઉપયોગ કરો.' },
]

export const SCHEMES = [
  { id: 'pmkisan',    name: 'PM-KISAN',                cat: 'Agriculture', icon: '🌾', benefit: '₹6,000/year',             target: 'Farmers' },
  { id: 'ayushman',   name: 'Ayushman Bharat',          cat: 'Health',      icon: '🏥', benefit: '₹5 Lakh health cover',     target: 'BPL Families' },
  { id: 'pmay',       name: 'PM Awas Yojana',           cat: 'Housing',     icon: '🏠', benefit: '₹2.5 Lakh subsidy',        target: 'Homeless/EWS' },
  { id: 'mudra',      name: 'Mudra Loan (PMMY)',        cat: 'Business',    icon: '💼', benefit: 'Up to ₹10 Lakh',           target: 'Entrepreneurs' },
  { id: 'sukanya',    name: 'Sukanya Samriddhi Yojana', cat: 'Women',       icon: '👧', benefit: '7.6% interest p.a.',       target: 'Girl Child' },
  { id: 'mgnregs',    name: 'MGNREGS',                  cat: 'Employment',  icon: '🔨', benefit: '100 days employment',      target: 'Rural Labor' },
  { id: 'ujjwala',    name: 'PM Ujjwala Yojana',        cat: 'BPL/Women',   icon: '🔥', benefit: 'Free LPG connection',      target: 'BPL Women' },
  { id: 'atal',       name: 'Atal Pension Yojana',      cat: 'Pension',     icon: '👴', benefit: '₹1,000–5,000/month',      target: 'Unorganised sector' },
  { id: 'kcc',        name: 'Kisan Credit Card',        cat: 'Agriculture', icon: '💳', benefit: 'Up to ₹3 Lakh credit',    target: 'Farmers' },
  { id: 'pmscholar',  name: 'PM Scholarship Scheme',    cat: 'Education',   icon: '🎓', benefit: '₹25,000/year',             target: 'Students' },
  { id: 'standup',    name: 'Stand Up India',           cat: 'Business',    icon: '💪', benefit: '₹10 Lakh–1 Crore',        target: 'SC/ST/Women' },
  { id: 'pmmvy',      name: 'PM Matru Vandana Yojana',  cat: 'Women',       icon: '🤱', benefit: '₹5,000 cash benefit',      target: 'Pregnant women' },
  { id: 'nsp',        name: 'National Scholarship Portal',cat:'Education',  icon: '📚', benefit: 'Multiple scholarships',    target: 'Students' },
  { id: 'pmsby',      name: 'PM Suraksha Bima Yojana',  cat: 'Insurance',   icon: '🛡️', benefit: '₹2 Lakh accident cover',   target: 'All citizens 18–70' },
  { id: 'pmjdy',      name: 'Jan Dhan Yojana',          cat: 'Finance',     icon: '🏦', benefit: 'Zero balance bank account', target: 'Unbanked citizens' },
]

export const STATE_SCHEMES = {
  'Andhra Pradesh': [
    'YSR Rythu Bharosa — ₹13,500/year to farmers',
    'YSR Aarogyasri — Free health coverage up to ₹5L',
    'Jagananna Vidya Deevena — Fee reimbursement for students',
    'YSR Navasakam — Housing for homeless',
  ],
  'Tamil Nadu': [
    'Kalaignar Magalir Urimai Thogai — ₹1,000/month for women',
    'Amma Unavagam — Subsidised food for workers',
    'CM Solar Powered Green House Scheme',
    'Pudhumai Penn — Higher education for girls',
  ],
  'Maharashtra': [
    'Mahatma Phule Jan Arogya Yojana — Health coverage ₹1.5L',
    'Ladli Laxmi — Support for girl child',
    'Mukhyamantri Annadan Yojana — Subsidised food grains',
    'Balasaheb Thackeray Udyogmitra — Youth entrepreneurship',
  ],
  'Uttar Pradesh': [
    'Kanya Sumangala Yojana — ₹15,000 for girl child',
    'UP Mukhyamantri Jan Arogya Yojana — Free treatment',
    'Mukhyamantri Awas Yojana — Rural housing',
    'UP Free Laptop Yojana — For meritorious students',
  ],
  'Karnataka': [
    'Gruha Jyothi — Free 200 units electricity/month',
    'Gruha Lakshmi — ₹2,000/month for women head of family',
    'Anna Bhagya — 10 kg free rice/month',
    'Yuva Nidhi — ₹3,000/month for unemployed graduates',
  ],
  'West Bengal': [
    'Lakshmir Bhandar — ₹500–1,000/month for women',
    'Swasthya Sathi — Free health cover up to ₹5L',
    'Krishak Bandhu — ₹4,000/acre for farmers',
    'Jai Johar — Tribal development scheme',
  ],
  'Gujarat': [
    'Namo Lakshmi Yojana — ₹50,000 for girl students',
    'Mukhyamantri Mahila Utkarsh Yojana — Women SHG loans',
    'iKhedut Portal — Farmer subsidies & benefits',
    'Mukhyamantri Apprenticeship Yojana — Youth skill training',
  ],
  'Telangana': [
    'Rythu Bandhu — ₹10,000/acre/year for farmers',
    'Rythu Bima — ₹5 Lakh farmer life insurance',
    'KCR Kit — Maternal & child health support',
    'TS-iPASS — Industry & business facilitation',
  ],
  'Rajasthan': [
    'CM Anuprati Coaching Scheme — Free coaching for competitive exams',
    'Chiranjeevi Swasthya Bima Yojana — ₹25 Lakh health cover',
    'Palanhar Yojana — Support for orphaned children',
    'Rajasthan Jan Soochna Portal — Transparent public services',
  ],
  'Madhya Pradesh': [
    'Ladli Behna Yojana — ₹1,250/month for women',
    'Mukhyamantri Kisan Kalyan Yojana — ₹4,000 additional for farmers',
    'CM Awasiya Bhu-Adhikar Yojana — Land rights for rural poor',
    'Sikho Kamao Yojana — ₹8,000–10,000/month for youth training',
  ],
}

export const ALERTS = [
  {
    id: 1,
    title: 'PM-KISAN 19th Installment',
    desc: 'Next installment due soon. Ensure Aadhaar-bank linkage is active and e-KYC is complete.',
    date: 'Mar 16, 2026',
    color: 'yellow',
    icon: '⏰',
    priority: 'high',
    scheme: 'PM-KISAN',
  },
  {
    id: 2,
    title: 'Ayushman Bharat New Enrollment',
    desc: 'New enrollment drive open for BPL families not yet covered. Apply at your nearest CSC centre.',
    date: 'Apr 1, 2026',
    color: 'teal',
    icon: '🏥',
    priority: 'high',
    scheme: 'Ayushman Bharat',
  },
  {
    id: 3,
    title: 'PM Scholarship Portal Open',
    desc: 'Applications open for 2026–27 academic session. Merit + need-based. Apply at scholarships.gov.in.',
    date: 'Apr 30, 2026',
    color: 'blue',
    icon: '🎓',
    priority: 'medium',
    scheme: 'PM Scholarship',
  },
  {
    id: 4,
    title: 'MGNREGS Job Card Renewal',
    desc: 'Annual job card renewal window is open. Visit your local Gram Panchayat office.',
    date: 'Mar 31, 2026',
    color: 'green',
    icon: '🔨',
    priority: 'medium',
    scheme: 'MGNREGS',
  },
  {
    id: 5,
    title: 'Mudra Loan Camp',
    desc: 'Special Mudra Loan awareness camps being held at district level. Bring business plan & Aadhaar.',
    date: 'Mar 20, 2026',
    color: 'purple',
    icon: '💼',
    priority: 'low',
    scheme: 'Mudra Loan',
  },
]

export const QUICK_PROMPTS = [
  { label: 'Am I eligible for PM-KISAN?',        query: 'Am I eligible for PM-KISAN as a farmer? What are the criteria?' },
  { label: 'Ayushman Bharat documents',           query: 'What documents do I need to get the Ayushman Bharat health card?' },
  { label: 'Mudra Loan steps',                    query: 'Give me step-by-step process to apply for Mudra Loan for my small business.' },
  { label: 'Schemes for women entrepreneurs',     query: 'List all government schemes available for women entrepreneurs in India.' },
  { label: 'Senior citizen benefits',             query: 'What are all the government benefits and schemes available for senior citizens above 60 years in India?' },
  { label: 'Education scholarships SC/ST',        query: 'What education scholarships are available for SC/ST students in India?' },
]

export const AWS_SERVICES = [
  { name: 'Amazon Bedrock',    desc: 'LLM inference via Claude 3 Sonnet — core AI engine',      icon: '🤖', color: 'from-orange-500/20 to-orange-600/5',  border: 'border-orange-500/20' },
  { name: 'AWS Lambda',        desc: 'Serverless compute — handles all backend logic & routing', icon: '⚡', color: 'from-yellow-500/20 to-yellow-600/5',  border: 'border-yellow-500/20' },
  { name: 'Amazon S3',         desc: 'Government scheme document store powering RAG pipeline',   icon: '🗄️', color: 'from-green-500/20 to-green-600/5',   border: 'border-green-500/20'  },
  { name: 'Amazon DynamoDB',   desc: 'User sessions, queries, alerts & scheme metadata',         icon: '📊', color: 'from-blue-500/20 to-blue-600/5',    border: 'border-blue-500/20'   },
  { name: 'API Gateway',       desc: 'REST API management, throttling & request routing',        icon: '🌐', color: 'from-purple-500/20 to-purple-600/5', border: 'border-purple-500/20' },
  { name: 'Amazon Transcribe', desc: 'Speech-to-Text (STT) — converts voice queries to text',   icon: '🎤', color: 'from-teal-500/20 to-teal-600/5',    border: 'border-teal-500/20'   },
  { name: 'Amazon Polly',      desc: 'Text-to-Speech (TTS) — reads AI responses aloud',         icon: '🔊', color: 'from-pink-500/20 to-pink-600/5',    border: 'border-pink-500/20'   },
  { name: 'Amazon Cognito',    desc: 'User authentication, registration & session management',   icon: '🔐', color: 'from-indigo-500/20 to-indigo-600/5', border: 'border-indigo-500/20' },
  { name: 'Amazon SNS',        desc: 'Push alerts & deadline notifications to users',            icon: '🔔', color: 'from-red-500/20 to-red-600/5',      border: 'border-red-500/20'    },
  { name: 'Amazon CloudFront', desc: 'CDN for low-latency global delivery — works on 2G',       icon: '☁️', color: 'from-sky-500/20 to-sky-600/5',      border: 'border-sky-500/20'    },
  { name: 'Amazon RDS (MySQL)','desc': 'Structured DB — user profiles, scheme metadata',        icon: '🗂️', color: 'from-lime-500/20 to-lime-600/5',    border: 'border-lime-500/20'   },
  { name: 'AWS Amplify',       desc: 'Hosts React.js frontend with CI/CD pipeline',             icon: '🚀', color: 'from-amber-500/20 to-amber-600/5',  border: 'border-amber-500/20'  },
]

export const FLOW_STEPS = [
  { step: '1', label: 'User Input',      desc: 'Voice (Transcribe) or text via React UI',   icon: '👤', color: 'bg-saffron/20 border-saffron/30'   },
  { step: '2', label: 'API Gateway',     desc: 'Routes request to Lambda function',          icon: '🌐', color: 'bg-purple-500/20 border-purple-500/30' },
  { step: '3', label: 'AWS Lambda',      desc: 'FastAPI backend processes query',             icon: '⚡', color: 'bg-yellow-500/20 border-yellow-500/30' },
  { step: '4', label: 'RAG on S3',       desc: 'Retrieves relevant scheme documents',         icon: '🗄️', color: 'bg-green-500/20 border-green-500/30'  },
  { step: '5', label: 'Bedrock / LLM',   desc: 'Claude 3 Sonnet generates answer',           icon: '🤖', color: 'bg-orange-500/20 border-orange-500/30' },
  { step: '6', label: 'DynamoDB',        desc: 'Session & result stored',                    icon: '📊', color: 'bg-blue-500/20 border-blue-500/30'    },
  { step: '7', label: 'Response',        desc: 'Text + Polly TTS delivered to user',         icon: '✅', color: 'bg-teal/20 border-teal/30'            },
]
