export const SCHEMES = [
  { id:'pmkisan',    name:'PM-KISAN',                 cat:'Agriculture', icon:'🌾', benefit:'₹6,000/year',           ministry:'Agriculture & Farmers Welfare' },
  { id:'ayushman',  name:'Ayushman Bharat (PMJAY)',   cat:'Health',      icon:'🏥', benefit:'₹5 Lakh health cover',  ministry:'Health & Family Welfare' },
  { id:'pmay',      name:'PM Awas Yojana (Urban)',    cat:'Housing',     icon:'🏠', benefit:'₹2.5 Lakh subsidy',    ministry:'Housing & Urban Affairs' },
  { id:'pmayg',     name:'PM Awas Yojana (Gramin)',   cat:'Housing',     icon:'🏡', benefit:'₹1.2 Lakh assistance', ministry:'Rural Development' },
  { id:'mudra',     name:'PM Mudra Yojana',           cat:'Business',    icon:'💼', benefit:'Up to ₹10 Lakh loan',  ministry:'Finance' },
  { id:'sukanya',   name:'Sukanya Samriddhi Yojana',  cat:'Women',       icon:'👧', benefit:'7.6% interest rate',   ministry:'Finance' },
  { id:'mgnregs',   name:'MGNREGS',                   cat:'Employment',  icon:'🔨', benefit:'100 days/yr employment',ministry:'Rural Development' },
  { id:'ujjwala',   name:'PM Ujjwala Yojana 2.0',     cat:'BPL/Women',   icon:'🔥', benefit:'Free LPG connection',  ministry:'Petroleum & Natural Gas' },
  { id:'atal',      name:'Atal Pension Yojana',        cat:'Pension',     icon:'👴', benefit:'₹1,000–5,000/month',  ministry:'Finance' },
  { id:'kcc',       name:'Kisan Credit Card',          cat:'Agriculture', icon:'💳', benefit:'Up to ₹3 Lakh credit',ministry:'Agriculture & Farmers Welfare' },
  { id:'pmscholar', name:'PM Scholarship Scheme',      cat:'Education',   icon:'🎓', benefit:'₹25,000/year',         ministry:'Home Affairs' },
  { id:'standup',   name:'Stand Up India',             cat:'Business',    icon:'💪', benefit:'₹10L–1Cr loan',        ministry:'Finance' },
  { id:'pmmvy',     name:'PM Matru Vandana Yojana',    cat:'Women',       icon:'🤱', benefit:'₹5,000 cash benefit',  ministry:'Women & Child Development' },
  { id:'nfsa',      name:'National Food Security Act', cat:'BPL',         icon:'🍚', benefit:'5 kg grain @ ₹1–3/kg',ministry:'Consumer Affairs & Food' },
  { id:'pmsby',     name:'PM Suraksha Bima Yojana',    cat:'Insurance',   icon:'🛡️', benefit:'₹2 Lakh accident cover',ministry:'Finance' },
  { id:'pmjjby',    name:'PM Jeevan Jyoti Bima',       cat:'Insurance',   icon:'❤️', benefit:'₹2 Lakh life cover',   ministry:'Finance' },
  { id:'fasal',     name:'PM Fasal Bima Yojana',       cat:'Agriculture', icon:'🌱', benefit:'Crop insurance',        ministry:'Agriculture & Farmers Welfare' },
  { id:'swachh',    name:'Swachh Bharat Mission',      cat:'Sanitation',  icon:'🚿', benefit:'Free toilet construction',ministry:'Jal Shakti' },
]

export const STATE_SCHEMES = {
  'Andhra Pradesh': [
    { name:'YSR Rythu Bharosa',         benefit:'₹13,500/year to farmers' },
    { name:'YSR Aarogyasri',            benefit:'Free medical up to ₹5 Lakh' },
    { name:'Jagananna Vidya Deevena',   benefit:'Full fee reimbursement for students' },
    { name:'YSR Cheyutha',              benefit:'₹18,750/year to BC/SC/ST women' },
  ],
  'Tamil Nadu': [
    { name:'Kalaignar Magalir Urimai',  benefit:'₹1,000/month to women household heads' },
    { name:'Amma Unavagam',             benefit:'Subsidised meals at ₹1' },
    { name:'CM Solar Green House',      benefit:'Free solar power for poor families' },
  ],
  'Maharashtra': [
    { name:'Mahatma Phule Jan Arogya',  benefit:'Health cover for BPL families' },
    { name:'Ladli Laxmi Yojana',        benefit:'₹1 Lakh for girl child' },
    { name:'Mukhyamantri Annadan',      benefit:'Free food grain to BPL' },
  ],
  'Uttar Pradesh': [
    { name:'Kanya Sumangala Yojana',    benefit:'₹15,000 in 6 stages for girl child' },
    { name:'UP Jan Arogya Yojana',      benefit:'Free treatment for poor families' },
    { name:'UP CM Awas Yojana',         benefit:'Housing assistance for rural poor' },
  ],
  'Karnataka': [
    { name:'Gruha Jyothi Scheme',       benefit:'200 units free electricity/month' },
    { name:'Gruha Lakshmi Scheme',      benefit:'₹2,000/month to women HH heads' },
    { name:'Anna Bhagya',              benefit:'10 kg rice/month to BPL families' },
    { name:'Yuva Nidhi Scheme',         benefit:'₹3,000/month to unemployed graduates' },
  ],
  'West Bengal': [
    { name:'Lakshmir Bhandar',          benefit:'₹500–1,000/month to women' },
    { name:'Swasthya Sathi',            benefit:'₹5 Lakh health cover per family' },
    { name:'Krishak Bandhu',            benefit:'₹10,000/year to farmers' },
  ],
  'Gujarat': [
    { name:'Namo Lakshmi Yojana',       benefit:'₹10,000/year to girl students' },
    { name:'CM Mahila Utkarsh Yojana',  benefit:'Interest-free loans for women SHGs' },
    { name:'iKhedut Portal',            benefit:'Agricultural subsidies and benefits' },
  ],
  'Telangana': [
    { name:'Rythu Bandhu',              benefit:'₹10,000/year per acre to farmers' },
    { name:'Rythu Bima',                benefit:'Free life insurance to farmers' },
    { name:'KCR Kit',                   benefit:'Newborn kit worth ₹12,000' },
  ],
  'Rajasthan': [
    { name:'CM Anuprati Coaching',      benefit:'Free coaching for competitive exams' },
    { name:'Chiranjeevi Swasthya Bima', benefit:'₹25 Lakh health cover/year' },
    { name:'Palanhar Yojana',           benefit:'Support for orphaned children' },
  ],
  'Madhya Pradesh': [
    { name:'Ladli Behna Yojana',        benefit:'₹1,250/month to women' },
    { name:'CM Kisan Kalyan Yojana',    benefit:'₹6,000/year additional to farmers' },
    { name:'CM Awasiya Bhu-Adhikar',    benefit:'Land rights for landless poor' },
  ],
}

export const LANGUAGES = [
  { code:'en', label:'English',   apiLang:'en-IN', prompt:'Respond in clear, simple English.' },
  { code:'hi', label:'हिंदी',      apiLang:'hi-IN', prompt:'पूरा उत्तर हिंदी में देवनागरी लिपि में दें।' },
  { code:'ta', label:'தமிழ்',       apiLang:'ta-IN', prompt:'முழு பதிலையும் தமிழில் கொடுங்கள்.' },
  { code:'te', label:'తెలుగు',      apiLang:'te-IN', prompt:'మొత్తం సమాధానం తెలుగులో ఇవ్వండి.' },
  { code:'bn', label:'বাংলা',       apiLang:'bn-IN', prompt:'সম্পূর্ণ উত্তর বাংলায় দিন।' },
  { code:'mr', label:'मराठी',      apiLang:'mr-IN', prompt:'संपूर्ण उत्तर मराठीत द्या.' },
  { code:'kn', label:'ಕನ್ನಡ',      apiLang:'kn-IN', prompt:'ಸಂಪೂರ್ಣ ಉತ್ತರವನ್ನು ಕನ್ನಡದಲ್ಲಿ ನೀಡಿ.' },
  { code:'gu', label:'ગુજરાતી',    apiLang:'gu-IN', prompt:'સંપૂર્ણ જવાબ ગુજરાતીમાં આપો.' },
]

export const ALERTS = [
  { id:1, title:'PM-KISAN Installment',       desc:'Next installment due soon. Ensure Aadhaar–bank linkage is active.',  date:'Mar 16, 2026', color:'yellow', icon:'⏰' },
  { id:2, title:'Ayushman Bharat Enrollment', desc:'New enrollment drive open for BPL families. Apply before deadline.', date:'Apr 1, 2026',  color:'teal',   icon:'🏥' },
  { id:3, title:'PM Scholarship Portal',      desc:'Applications open for 2026–27 session. Merit and need-based.',       date:'Apr 30, 2026', color:'blue',   icon:'🎓' },
  { id:4, title:'MGNREGS Job Card Renewal',   desc:'Annual job card renewal window is open. Visit your Gram Panchayat.', date:'Mar 31, 2026', color:'green',  icon:'🔨' },
  { id:5, title:'PM Ujjwala 2.0 Camps',       desc:'Free LPG connection camps being held across rural areas this month.',date:'Mar 20, 2026', color:'orange', icon:'🔥' },
]
