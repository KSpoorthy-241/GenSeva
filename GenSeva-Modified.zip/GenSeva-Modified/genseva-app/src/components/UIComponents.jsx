import React from 'react'

// ── TypingIndicator ───────────────────────────────────
export function TypingIndicator() {
  return (
    <div className="flex gap-2.5 bubble-in">
      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-teal to-govt-2 flex items-center justify-center text-sm shrink-0">
        🤖
      </div>
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center gap-3 px-4 py-3 bg-white/[0.06] border border-white/[0.09] rounded-2xl rounded-bl-sm">
          <div className="flex gap-1.5">
            <div className="typing-dot" />
            <div className="typing-dot" />
            <div className="typing-dot" />
          </div>
          <span className="text-[11px] text-white/30">Searching RAG knowledge base…</span>
        </div>
        <span className="text-[10px] text-white/20 px-1">Amazon Bedrock is processing</span>
      </div>
    </div>
  )
}

// ── SkeletonLine ──────────────────────────────────────
export function SkeletonLines({ count = 6 }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className={`h-3 rounded shimmer-bg ${i % 3 === 2 ? 'w-1/2' : i % 2 === 0 ? 'w-3/4' : 'w-full'}`}
        />
      ))}
      <div className="flex items-center gap-2 text-xs text-teal-2 mt-2 pt-1">
        <div className="w-3 h-3 border border-teal-2/30 border-t-teal-2 rounded-full animate-spin" />
        <span>Querying RAG pipeline · Amazon Bedrock · S3 Document Store…</span>
      </div>
    </div>
  )
}

// ── RAGBadge ──────────────────────────────────────────
export function RAGBadge() {
  return (
    <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded bg-teal/10 border border-teal/20 text-teal-2/70">
      📡 RAG · S3 · Bedrock
    </span>
  )
}

// ── SectionHeader ─────────────────────────────────────
export function SectionHeader({ title, subtitle }) {
  return (
    <div className="mb-6">
      <h1 className="text-2xl font-bold text-white">{title}</h1>
      {subtitle && <p className="text-sm text-white/40 mt-1">{subtitle}</p>}
    </div>
  )
}

// ── StatCard ──────────────────────────────────────────
export function StatCard({ icon, value, label }) {
  return (
    <div className="card p-5 text-center hover:border-white/15 transition-all group">
      <div className="text-2xl mb-2">{icon}</div>
      <div className="text-2xl font-bold text-teal-2 group-hover:scale-105 transition-transform">{value}</div>
      <div className="text-xs text-white/35 mt-1">{label}</div>
    </div>
  )
}

// ── FeatureCard ───────────────────────────────────────
export function FeatureCard({ icon, title, desc }) {
  return (
    <div className="card p-5 hover:border-teal/30 hover:-translate-y-1 transition-all group cursor-default">
      <div className="text-2xl mb-3">{icon}</div>
      <div className="text-sm font-semibold text-white mb-1 group-hover:text-teal-2 transition-colors">{title}</div>
      <div className="text-[11px] text-white/40 leading-relaxed">{desc}</div>
    </div>
  )
}

// ── ProblemCard ───────────────────────────────────────
export function ProblemCard({ icon, title, desc }) {
  return (
    <div className="card p-4 text-center hover:border-saffron/20 transition-all">
      <div className="text-3xl mb-3">{icon}</div>
      <div className="text-sm font-semibold text-white/80 mb-1">{title}</div>
      <div className="text-[11px] text-white/40 leading-relaxed">{desc}</div>
    </div>
  )
}
