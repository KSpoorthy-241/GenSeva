import { Link, useLocation } from 'react-router-dom'
import { useState } from 'react'
import { LANGUAGES } from '../data/schemes'
import T from '../data/translations'

export default function Navbar({ lang, setLang }) {
  const { pathname } = useLocation()
  const [open, setOpen] = useState(false)
  const t = T[lang] || T.en

  const NAV = [
    { path:'/',            label:t.home,        icon:'🏛️' },
    { path:'/chat',        label:t.chat,        icon:'💬' },
    { path:'/schemes',     label:t.schemes,     icon:'📋' },
    { path:'/eligibility', label:t.eligibility, icon:'✅' },
    { path:'/alerts',      label:t.alerts,      icon:'🔔' },
  ]

  return (
    <nav className="sticky top-0 z-50 border-b border-green-200 shadow-sm"
      style={{background:'rgba(254,253,232,0.97)', backdropFilter:'blur(12px)'}}>
      <div className="flex items-center justify-between px-4 md:px-6 h-14">

        {/* Logo — bicolor Gen(dark) + Seva(orange) */}
        <Link to="/" className="flex items-center gap-2.5 shrink-0">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center text-base shadow"
            style={{background:'linear-gradient(135deg,#ea580c,#f97316)'}}>🏛️</div>
          <div>
            <div className="text-base font-extrabold leading-none" style={{fontFamily:'Sora,sans-serif'}}>
              <span style={{color:'#1a2e1a'}}>Gen</span><span style={{color:'#f97316'}}>Seva</span>
            </div>
            <div className="text-[9px] tracking-widest uppercase" style={{color:'#f97316', opacity:0.7, fontFamily:'Sora,sans-serif'}}>AI for Bharat</div>
          </div>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-0.5">
          {NAV.map(n => (
            <Link key={n.path} to={n.path}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
                pathname === n.path
                  ? 'text-white border-transparent shadow'
                  : 'text-green-800 border-transparent hover:bg-green-100'
              }`}
              style={pathname === n.path ? {background:'linear-gradient(135deg,#16a34a,#15803d)'} : {}}>
              {n.icon} {n.label}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {/* Live · Amazon Bedrock dot */}
          <div className="flex items-center gap-1.5 rounded-full px-3 py-1.5 border border-green-400"
            style={{background:'rgba(255,255,255,0.7)'}}>
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-[10px] text-green-700 font-semibold hidden sm:block">{t.live}</span>
          </div>

          <button onClick={() => setOpen(!open)} className="md:hidden text-green-800 text-xl w-8 h-8 flex items-center justify-center">
            {open ? '✕' : '☰'}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t border-green-300 px-4 py-3 flex flex-col gap-1"
          style={{background:'#fefde8'}}>
          {NAV.map(n => (
            <Link key={n.path} to={n.path} onClick={() => setOpen(false)}
              className={`px-3 py-2.5 rounded-lg text-sm font-medium ${
                pathname === n.path ? 'text-white' : 'text-green-800 hover:bg-green-100'
              }`}
              style={pathname === n.path ? {background:'linear-gradient(135deg,#16a34a,#15803d)'} : {}}>
              {n.icon}  {n.label}
            </Link>
          ))}
        </div>
      )}
    </nav>
  )
}
