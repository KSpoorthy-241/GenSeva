import T from '../data/translations'
export default function Footer({ lang }) {
  const t = T[lang] || T.en
  return (
    <footer className="border-t px-4 py-4" style={{background:'rgba(255,255,255,0.5)', borderColor:'#fed7aa'}}>
      <p className="text-center text-xs" style={{color:'#92400e', opacity:0.7}}>
        {t.footerText}
      </p>
    </footer>
  )
}
