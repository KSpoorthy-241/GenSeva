import { LANGUAGES } from '../data/schemes'

export default function LangBar({ lang, setLang }) {
  return (
    <div className="border-b border-orange-200 px-4 py-2.5 flex items-center gap-2 flex-wrap"
      style={{background:'rgba(255,255,255,0.6)'}}>
      <span className="text-[10px] tracking-widest uppercase font-bold"
        style={{color:'#ea580c'}}>Language:</span>
      {LANGUAGES.map(l => (
        <button key={l.code} onClick={() => setLang(l.code)}
          className={`px-3 py-1 rounded-full text-xs font-semibold border transition-all ${
            lang === l.code
              ? 'text-white border-transparent shadow'
              : 'border-gray-300 text-gray-700 hover:border-orange-400 hover:text-orange-700'
          }`}
          style={lang === l.code
            ? {background:'linear-gradient(135deg,#1a2e1a,#14532d)'}
            : {background:'rgba(255,255,255,0.8)'}}>
          {l.label}
        </button>
      ))}
    </div>
  )
}
